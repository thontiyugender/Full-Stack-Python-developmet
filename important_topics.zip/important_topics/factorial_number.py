def compute_factorial(n):
    factorial=1
    if n<0:
        print("sorry factorial does not exist for negative number")
    elif(n==0):
        print("The facorial of 0  is: 1")
    else:
        for i in range(1,n+1):
            factorial=factorial*i
        print("the factorail",n,"is",factorial)

compute_factorial(int(input("Enter the number:")))


# memo=  {}
# def factorial_memory(n):
#     if n == 0:
#         return 1
#     if n in memo:
#         return memo[n]
#     memo[n]=n*factorial_memory(n-1)
#     return memo[n]
# factorial_memory(int(input("Enter the number:")))


