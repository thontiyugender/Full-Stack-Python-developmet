#####..........======removing duplicate values========.......######

# l=[1,2,3,4,5,6,1,2,3]
# m=[]
# print(l)
# for x in l:
#     if x not in m:
#         m.append(x)
# print(m)

######........finding even and odd........#####

# m=[1,2,5,3,5,6,4,6,54,39,78,45]
# l=[]
# n=[]
# for i in range(len(m)):
#     if(m[i]%2==0):
#         l.append(m[i])
#     else:
#         n.append(m[i])
# print("even:",l)
# print("odd:",n)

# '''''''22###.....////......prime numbers coding....../////.....####'''''''



# # n=int(input("enter the number:"))
# # b=str(n)
# # for i in range(2,n):
# #     if n%i==0:
# #         print("it is not a prime number",n)
# #         break 
# # else:
# #     print("it is prime number",n)


# # print()
# # n=int(input("enter the number:"))
# # b=str(n)
# # for i in range (2,n):
# #     if (n%i==0):
# #         print("prime")
# #         break
# # else:
# #     print("not prime")


# # yugender="917741981"
# # print("yugender is:",yugender)
# # print()
# # print("the data type is:",type(yugender))
# # res1=str(yugender)
# # print("yugender is:",res1)
# # print()
# # print("the data type is:",type(res1))


# # x="1211"
# # y="55454"
# # res=x+y
# # print(res)

# ####..... strings into addittion....

# # x="1211"
# # y="55454"
# # num=int(x)
# # num1=int(y)
# # res=num+num1
# # print(res)



# ##......palindriome are the reverse of the object....

# str1=input("enter the string object:")
# if(str1==str1[::-1]):
#     print(str1,str1[::-1],"----> given string is palindrome string")
# else:
#      print(str1,str1[::-1],"----> given string is  not palindrome string")    
# print()


'''str2=""
for str1 in "abcd":
    str2=str1+str2
print("reverse of a string is:",str2)

import time 
str1=input("Enter the string_Object:")
str2=""
for x1 in range(len(str1)):
    str2=str1[x1]+str2 
print()
if(str1==str2):
    print(str1,str2,":Palindrom_object")
else:
    print(str1,str2,":Not a Palindom object")
print()
time.sleep(2)
print('End of an application')


str1=input("enter the string object:")
str2=""
for str1 in"dad":
    str2=str1[::-1]
print("reverse of a string is:",str2)
print()      

str1=input("enter the string object : ")
str2=''
for str1 in 'dad':
    str2=str1[::-1]
print("reverse of a string:",str2)'''


# for i in range(4):
#     print(i)
#     for j in range(4):
#         print(j)
# print()

# for i in range(4):
#     for j in range(4):
#         print(i)
#         print(j)
# print()     



# c1=0
# c2=0
# for x1 in"software developer":
#     if(x1 in("AEIOUaeiou")):
#         c1+=1
#         print("vowels are",c1,x1)
# for x2 in "software developer":
#     if(x2 not in ("AEIOUaeiou")):
#         c2+=1
#         print(c2,x2)
# print(c1,"and",c2)

######======fibonacci series========
#====================================


'''l1=[]
for x in range(0,10):
    if x<3:
        l1.append(x)
    elif x>=3:
        newval=l1[len(l1)-1]+l1[len(l1)-2]
        l1.append(newval)
for x in l1:
    print(x,end=" ")
print()
'''
# ####........using sort.....
# # sort is used to give values in lower to higher order.. 

# l2=[]
# n=eval(input("enter the number of rows:"))
# for x1 in range(1,n+1):
#     obj1=eval(input("enter the number of objects:"))
#     l2.append(obj1)
# print("our list objects are:",l2)
# print()
# l2.sort()
# print("our list objects are :",l2)


##.................finding highest value in the rows.........
'''l2=[]
n=eval(input("enter the number of rows:"))
for x1 in range(1,n+1):
    obj1=eval(input('enter the list objects:'))
    l2.append(obj1)
print("our list_objects are:",l2)
print()
l2.sort()
print(l2)
print("largest in the list is :",l2[n-1])
print("second largest in the list is:",l2[n-2])
print("third largest in the list is :",l2[n-3])
'''



# string contactination...

####....count...///

a=input("enter the character")
c=a.count(a)


# PYHTON FUNCTION ARGUMENTS:
# ==========================

# the arguments is a value,a variable,or an object that we pass to a function or method call..
# in python,there are four types of arguments allowed.

# 1.positional arguments
# 2.keyword arguments
# 3.default arguments
# 4.variable length arguments


