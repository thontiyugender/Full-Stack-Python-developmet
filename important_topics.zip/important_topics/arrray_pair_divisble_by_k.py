# array pair sum divisible by k

# write a function to check if an array can be divided onto pairs 
# such that the sum of every pair divisble by k

# arr=[9,7,5,3],k=6

def can_divide_into_pairs(arr,k):
    remainder_count=[0]*k

    for num in arr:
        remainder_count[num%k]+=1

    for i in range(1,k):
        if remainder_count[i]!=remainder_count[k-i]:
            return False
        
    return remainder_count[0]%2==0

print(can_divide_into_pairs([9,7,5,3],6))

