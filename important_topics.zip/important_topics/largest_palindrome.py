
# write a function to find the largest palindrome substring in a given string  


# "babad"      ex: "bab" or "aba"


def largest_palindrome(s):
    def is_palindrome(substr):
        return substr==substr[::-1]
    

    max_length=0
    result=" "

    for i in range(len(s)):
        for j in range(i,len(s)):
            if is_palindrome(s[i:j+1]) and (j-i+1)>max_length:
                max_length=j-i+1

                result=s[i:j+1]

    return result

print(largest_palindrome("babad"))

