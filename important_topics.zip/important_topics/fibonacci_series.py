# 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...



# def fibonacci_series(n):
#     a, b = 0, 1
#     for _ in range(n):
#         print(a, end=" ")
#         a, b = b, a + b

# # Example: Generate the first 10 numbers
# fibonacci_series(10)
# print()



# a=0
# b=1
# for i in range(10):
#     print(a,end=" ")
#     a,b=b,a+b



# def fibonacci_series(n):
#     a,b=0,1
#     for m in range(10):
#         print(a,end=" ")
#         a,b=b,a+b

# fibonacci_series(10)



# print()


a=0
b=1
for i in range(10):
    c=a+b
    a=b
    b=c
    print(c,end=" ")

