# write a function to find a second largest number in a list

def second_largest(n):
    unique_numbers=list(set(n))
    unique_numbers.sort()
    return unique_numbers[-2] if len(unique_numbers)>=2 else None


n=[4,1,7,4,3,7]
# second_largest(n)
print(second_largest(n))

# def second_largest(n):
#     unique_numbers=list(set(n))
#     unique_numbers.sort
#     if len(unique_numbers)>=2:
#         print(unique_numbers[-2])
#     else:
#         None

# n=[4,1,3,7,4,5]
# second_largest(n)


