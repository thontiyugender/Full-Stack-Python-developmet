# Data Base style questions:
# ==========================

data=[{"name":"Alice","age":25},{"name":"Bob","age":22},{"name":"charlie","age":23}]

def sort_by_key(data,key):
    return sorted(data,key=lambda x:x[key])
print(sort_by_key(data,"age"))



