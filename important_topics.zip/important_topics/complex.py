# x1=500+1000j
# print("the complex data type is:",x1)
# print()
# print(type(x1))




# x1=500+1000j
# print("the complex data type is:",x1)
# print()
# print(type(x1))
# print()
# print(x1.real)
# print()
# print("imaginary part from complex data type...")
# print(x1.imag)
# print()


x1=1000+200j
x2=-900-50j
res1=x1+x2
print(res1)

