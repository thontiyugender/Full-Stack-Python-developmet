#     write a python function to count the frequency of each character of a string...
# =======================================================================================


# def count_char_frequency(s):
#     frequency={}

#     for char in s:
#         frequency[char]=frequency.get(char,0)+1
#     return frequency

# print(count_char_frequency("accenture"))




# def count_frequency(s):
#     frequency={}

#     for char in s:
#         frequency[char]=frequency.get(char,0)+1
#     return frequency

# print(count_frequency("accenture"))

# set doesnot allow duplicate objects,so number will increase...

# {'a':1,'c':2,'e':2,'n':1,'t':1,'u':1,'r':1}


def count_char_frequency(s):
    frequency={}

    for char in s:
        frequency[char]=frequency.get(char,0)+1
    return frequency

print(count_char_frequency("accenture"))


