k=[]
l=[]
j=[1,2,3,4,5,6,8,5,6,5,8]
for i in range(len(j)):
    if j[i]%2==0:
        print("even number are:",j[i])
        k.append(j[i])
    else:
        print("odd number are:",j[i])
        l.append(j[i])

print("even number are:",k)
print("odd numbers are:",l)



