def second_largest_number(n):
    unique_numbers=list(set(n))
    unique_numbers.sort()
    return unique_numbers[-2] if len(unique_numbers)>=2 else -1
    

n=input("enter the number:")
print(second_largest_number(n))
print(n)


