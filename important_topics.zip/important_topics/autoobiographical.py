# def FindAutoCount (n):

#     if n is None:
#         return 0

#     digit_count=[0]*10

#     # Count the occurence of each digit in the input string
#     for digit in n:
#         digit =int(digit)
#         digit_count[digit]+=1

#     # Check the input number is autoboigraphical
#     for i in range(len(n)):
#         if digit_count[i]!= int(n[i]):
#             return 0
    
    
#     # count the number of distinct digits in the input number
#     distinct_count=sum(1 for count in digit_count if count>0)

#     return distinct_count


# #  take input..
# number=input("Enter number:")
# result=FindAutoCount(number)
# print(result)


# 6210001000


# def AutoFindCount(n):
#     if n is None:
#         return 0

#     digit_count=0*10
    
#     for digit in n:
#         digit=int(digit)
#         digit_count[digit]+=1

#     for i in range(len(n))–:
#         if digit_count[digit]!=int(n[i]):
#             return 0

#     distinct_count=sum(1 for count in digit_count if count>0)

#     return distinct_count

# number=input("Enter the number:")
# result=AutoFindCount(number)
# print(result)     


def AutoFindCount(n):
    if n is None:
        return 0
    
    digit_count=[0]*10

    for digit in n:
        digit=int(digit)
        digit_count[digit]+=1
        # a=digit_count[digit]+1

    for i in range(len(n)):
        if digit_count[i]!=int(n[i]):
        # if a!=int(n[i]):
            return 0

    distinct_count=sum(1 for count in digit_count if count>0)

    return distinct_count

number=input("Enter the number:")
result=AutoFindCount(number)
print(result)


# def findautocount(n):
#     if n is None:
#         return 0
    
#     digit_count=[0]*10
#     for digit in n:
#         digit=int(digit)
#         digit_count[digit]+=1


#     for i in range(len(n)):
#        if digit_count[i]!=int(n[i]):
#           return 0
    

#     distinct_count=sum(1 for count in digit_count if count>0)

#     return distinct_count

# n=input("enter the number:")
# result=findautocount(n)
# print(result)


