# x=5
# y=25


# temp=x
# x=y
# y=temp

# print("the value of x after swapping:",x)
# print("the value of y after swapping:",y)



# x=15
# y=25

# x,y=y,x
# print("the value of x after swapping:",x)
# print("the value of y after swapping:",y)




'''....prime number or not....'''

'''num=int(input("Enter the number:"))
def is_prime(num):
    if num<2:       #..check if the number is less than two...

        return False
    #  check for factors from 2 to the square root of the number
    for i in range(2,int(num**0.5)+1):
        if num%i==0:
            return False
    # if no factors found, the number is prime...
    return True

# num=int(input("Enter the number:"))
if is_prime(num):
    print(f"{num} is a prime number.")
else:
    print(f"{num} is not a prime number")
    '''