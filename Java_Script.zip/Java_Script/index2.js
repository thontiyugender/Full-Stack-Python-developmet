        
        var a=1000
        var b=2000
        var res1=a+b
        document.write("the result_set is:"+res1)
        console.log("the result_set is:"+res1)