// var Emp_number:number=1001;
// console.log("Employee_number is:"+Emp_number)
// var Eid:number=1001;
// var Ename:string="RAHul Sharma"
// var Esal:number=29000
// var Design:string="UI developer"
// var company:string="Wipro technologies"
// console.log("Eid is:"+Eid)
// console.log("Ename is:"+Ename)
// console.log("Esal is:"+Esal)
// console.log("Design is:"+Design)
// console.log("Company is:"+company)
// var products:any=[1001,"MObile_1",29000,"S1"]
// console.log(products)
// function Employee()
// {
//     console.log("this is function in typescript ")
// }
// Employee()
// function Employees(Eid:number,Ename:string,Esal:number,Design:string,company:string)
// {
// console.log("Eid is:"+Eid)
// console.log("Ename is:"+Ename)
// console.log("Esal is:"+Esal)
// console.log("Design is:"+Design)
// console.log("company is:"+company)
// }
// Employees(1001,"Rahul Sharma",29000,"Developer","TCS")
function Test_case1(x1, x2) {
    return x1 + x2;
}
console.log("sum is:", Test_case1(1001, 1002));
